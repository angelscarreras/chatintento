{
  "template": `
    <BottomNavigation>
      <TabStrip>
        <TabStripItem>
          <Label text="Chats" />
          <Image src="font://&#xf0e6;" class="fas" />
        </TabStripItem>
        <TabStripItem>
          <Label text="Profile" />
          <Image src="font://&#xf007;" class="fas" />
        </TabStripItem>
      </TabStrip>

      <TabContentItem>
        <Frame>
          <ChatList />
        </Frame>
      </TabContentItem>
      <TabContentItem>
        <Frame>
          <ProfileView />
        </Frame>
      </TabContentItem>
    </BottomNavigation>
  `,
  "script": `
    import { defineComponent } from 'nativescript-vue';
    import ChatList from '../chat/ChatList.vue';
    import ProfileView from '../profile/ProfileView.vue';

    export default defineComponent({
      components: {
        ChatList,
        ProfileView
      }
    });
  `
}