{
  "template": `
    <StackLayout class="p-4">
      <Label text="Welcome to Chat App" class="text-2xl font-bold text-center mb-4" />
      <TextField v-model="email" hint="Email" keyboardType="email" class="input mb-2" />
      <TextField v-model="password" hint="Password" secure="true" class="input mb-4" />
      <Button text="Login" @tap="handleLogin" class="btn btn-primary mb-2" />
      <Button text="Sign Up" @tap="handleSignup" class="btn btn-outline" />
      <ActivityIndicator :busy="isLoading" />
    </StackLayout>
  `,
  "script": `
    import { defineComponent, ref } from 'nativescript-vue';
    import { useAuthStore } from '../../stores/auth';

    export default defineComponent({
      setup() {
        const authStore = useAuthStore();
        const email = ref('');
        const password = ref('');
        const isLoading = ref(false);

        const handleLogin = async () => {
          if (!email.value || !password.value) return;
          
          isLoading.value = true;
          try {
            await authStore.login(email.value, password.value);
          } finally {
            isLoading.value = false;
          }
        };

        const handleSignup = () => {
          // Navigate to signup page
        };

        return {
          email,
          password,
          isLoading,
          handleLogin,
          handleSignup
        };
      }
    });
  `
}