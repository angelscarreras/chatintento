{
  "template": `
    <GridLayout columns="auto, *" :class="messageContainerClass">
      <Image col="0" :src="message.sender.avatar" class="rounded-circle w-8 h-8" 
             v-if="!isOwnMessage" />
      <StackLayout col="1" :class="messageBubbleClass">
        <Label :text="message.sender.name" class="text-xs text-gray-600" 
               v-if="!isOwnMessage" />
        <Label :text="message.content" textWrap="true" />
        <GridLayout columns="auto, auto" class="message-footer">
          <Label col="0" :text="formattedTime" class="text-xs text-gray-500" />
          <Label col="1" :text="statusIcon" class="ml-1" />
        </GridLayout>
      </StackLayout>
    </GridLayout>
  `,
  "script": `
    import { defineComponent, computed } from 'vue';
    import { useAuthStore } from '../../stores/auth';
    import { format } from 'date-fns';

    export default defineComponent({
      props: {
        message: {
          type: Object,
          required: true
        }
      },
      setup(props) {
        const authStore = useAuthStore();

        const isOwnMessage = computed(() => 
          props.message.sender.id === authStore.currentUser?.id
        );

        const messageContainerClass = computed(() => ({
          'message-container': true,
          'own-message': isOwnMessage.value,
          'other-message': !isOwnMessage.value,
          'p-2': true
        }));

        const messageBubbleClass = computed(() => ({
          'message-bubble': true,
          'p-3': true,
          'rounded-lg': true,
          'bg-primary': isOwnMessage.value,
          'bg-gray-200': !isOwnMessage.value,
          'ml-2': !isOwnMessage.value,
          'mr-2': isOwnMessage.value
        }));

        const formattedTime = computed(() => 
          format(new Date(props.message.timestamp), 'HH:mm')
        );

        const statusIcon = computed(() => {
          switch(props.message.status) {
            case 'sent': return '✓';
            case 'delivered': return '✓✓';
            case 'read': return '✓✓';
            default: return '🕐';
          }
        });

        return {
          isOwnMessage,
          messageContainerClass,
          messageBubbleClass,
          formattedTime,
          statusIcon
        };
      }
    });
  `
}