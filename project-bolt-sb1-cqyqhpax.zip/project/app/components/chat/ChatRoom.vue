{
  "template": `
    <Page>
      <ActionBar>
        <GridLayout columns="auto, *, auto">
          <Label col="0" text="←" class="action-item" @tap="goBack" />
          <StackLayout col="1" orientation="horizontal">
            <Image :src="chat.avatar" class="rounded-circle w-8 h-8" />
            <Label :text="chat.name" class="ml-2" />
          </StackLayout>
          <Label col="2" :text="chat.isOnline ? '🟢' : '⚫'" class="mr-2" />
        </GridLayout>
      </ActionBar>

      <GridLayout rows="*, auto">
        <ListView row="0" :items="messages" @loaded="onListViewLoaded">
          <template #default="{ item }">
            <MessageBubble :message="item" />
          </template>
        </ListView>

        <GridLayout row="1" columns="*, auto" class="input-bar p-2">
          <TextField col="0" v-model="newMessage" hint="Type a message..." 
                    returnKeyType="send" @returnPress="sendMessage" />
          <Button col="1" text="Send" @tap="sendMessage" 
                  class="btn btn-primary ml-2" :isEnabled="!!newMessage" />
        </GridLayout>
      </GridLayout>
    </Page>
  `,
  "script": `
    import { defineComponent, ref, computed, onMounted, onUnmounted } from 'vue';
    import { useChatStore } from '../../stores/chat';
    import MessageBubble from './MessageBubble.vue';

    export default defineComponent({
      components: { MessageBubble },
      props: {
        chatId: {
          type: String,
          required: true
        }
      },
      setup(props) {
        const chatStore = useChatStore();
        const newMessage = ref('');
        const listView = ref(null);

        const chat = computed(() => chatStore.getChatById(props.chatId));
        const messages = computed(() => chatStore.getMessagesByChatId(props.chatId));

        const sendMessage = async () => {
          if (!newMessage.value.trim()) return;
          
          await chatStore.sendMessage({
            chatId: props.chatId,
            content: newMessage.value,
            timestamp: new Date()
          });
          
          newMessage.value = '';
          scrollToBottom();
        };

        const scrollToBottom = () => {
          if (listView.value) {
            listView.value.nativeView.scrollToIndex(messages.value.length - 1);
          }
        };

        const onListViewLoaded = (args) => {
          listView.value = args.object;
          scrollToBottom();
        };

        const goBack = () => {
          navigateBack();
        };

        onMounted(() => {
          chatStore.joinChat(props.chatId);
          chatStore.fetchMessages(props.chatId);
        });

        onUnmounted(() => {
          chatStore.leaveChat(props.chatId);
        });

        return {
          chat,
          messages,
          newMessage,
          sendMessage,
          onListViewLoaded,
          goBack
        };
      }
    });
  `
}