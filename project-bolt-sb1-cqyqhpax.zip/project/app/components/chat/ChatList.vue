{
  "template": `
    <Page>
      <ActionBar title="Chats" />
      <GridLayout rows="*, auto">
        <ListView row="0" :items="chats" @itemTap="onChatTap">
          <template #default="{ item }">
            <ChatListItem :chat="item" />
          </template>
        </ListView>
        <Button row="1" text="New Chat" @tap="onNewChat" class="btn btn-primary m-2" />
      </GridLayout>
    </Page>
  `,
  "script": `
    import { defineComponent } from 'vue';
    import { useChatStore } from '../../stores/chat';
    import ChatListItem from './ChatListItem.vue';

    export default defineComponent({
      components: { ChatListItem },
      setup() {
        const chatStore = useChatStore();
        const chats = computed(() => chatStore.chats);

        const onChatTap = (event) => {
          const chatId = event.item.id;
          navigateTo('/chat/' + chatId);
        };

        const onNewChat = () => {
          navigateTo('/new-chat');
        };

        onMounted(() => {
          chatStore.fetchChats();
        });

        return {
          chats,
          onChatTap,
          onNewChat
        };
      }
    });
  `
}