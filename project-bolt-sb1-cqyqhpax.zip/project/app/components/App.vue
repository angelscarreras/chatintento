{
  "template": `
    <Frame>
      <Page>
        <NavigationComponent v-if="isAuthenticated" />
        <AuthComponent v-else />
      </Page>
    </Frame>
  `,
  "script": `
    import { defineComponent, computed } from 'nativescript-vue';
    import { useAuthStore } from '../stores/auth';
    import NavigationComponent from './navigation/NavigationComponent.vue';
    import AuthComponent from './auth/AuthComponent.vue';

    export default defineComponent({
      components: {
        NavigationComponent,
        AuthComponent
      },
      setup() {
        const authStore = useAuthStore();
        return {
          isAuthenticated: computed(() => authStore.isAuthenticated)
        };
      }
    });
  `
}