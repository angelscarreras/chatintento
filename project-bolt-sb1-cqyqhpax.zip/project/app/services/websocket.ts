import { WebSocket } from '@nativescript/websockets';
import { useAuthStore } from '../stores/auth';
import { useChatStore } from '../stores/chat';

class WebSocketService {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectTimeout = 1000;

  constructor() {
    this.connect();
  }

  private connect() {
    const authStore = useAuthStore();
    if (!authStore.token) return;

    this.ws = new WebSocket(
      `wss://api.chat-app.com/ws?token=${authStore.token}`,
      { timeout: 5000 }
    );

    this.ws.on('open', this.onOpen.bind(this));
    this.ws.on('message', this.onMessage.bind(this));
    this.ws.on('close', this.onClose.bind(this));
    this.ws.on('error', this.onError.bind(this));
  }

  private onOpen() {
    console.log('WebSocket connected');
    this.reconnectAttempts = 0;
  }

  private onMessage(socket: WebSocket, message: string) {
    try {
      const data = JSON.parse(message);
      const chatStore = useChatStore();

      switch (data.type) {
        case 'message':
          chatStore.addMessage(data.chatId, data.message);
          break;
        case 'status':
          chatStore.updateMessageStatus(data.messageId, data.status);
          break;
      }
    } catch (error) {
      console.error('Failed to process WebSocket message:', error);
    }
  }

  private onClose() {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      setTimeout(() => {
        this.reconnectAttempts++;
        this.connect();
      }, this.reconnectTimeout * this.reconnectAttempts);
    }
  }

  private onError(socket: WebSocket, error: Error) {
    console.error('WebSocket error:', error);
  }

  public sendMessage(message: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'message',
        data: message
      }));
    }
  }

  public joinChat(chatId: string) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'join',
        chatId
      }));
    }
  }

  public leaveChat(chatId: string) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'leave',
        chatId
      }));
    }
  }
}

export const websocketService = new WebSocketService();