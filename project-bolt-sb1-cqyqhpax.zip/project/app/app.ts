import { createApp, registerElement } from 'nativescript-vue';
import { createPinia } from 'pinia';
import App from './components/App.vue';
import { initializeWebSocket } from './services/websocket';
import { setupAxiosInterceptors } from './services/api';

// Register any custom elements
registerElement('ChatBubble', () => require('./components/chat/MessageBubble.vue').default);

const pinia = createPinia();
const app = createApp(App);

app.use(pinia);

// Initialize services
setupAxiosInterceptors();
initializeWebSocket();

app.start();