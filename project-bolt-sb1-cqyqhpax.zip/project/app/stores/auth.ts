import { defineStore } from 'pinia';
import { ref } from 'vue';
import { api } from '../services/api';
import { User } from '../types';

export const useAuthStore = defineStore('auth', () => {
  const currentUser = ref<User | null>(null);
  const token = ref<string | null>(null);

  const isAuthenticated = computed(() => !!token.value);

  async function login(email: string, password: string) {
    try {
      const response = await api.post('/auth/login', { email, password });
      token.value = response.data.token;
      currentUser.value = response.data.user;
      return true;
    } catch (error) {
      console.error('Login failed:', error);
      return false;
    }
  }

  async function signup(userData: {
    email: string;
    password: string;
    name: string;
  }) {
    try {
      const response = await api.post('/auth/signup', userData);
      token.value = response.data.token;
      currentUser.value = response.data.user;
      return true;
    } catch (error) {
      console.error('Signup failed:', error);
      return false;
    }
  }

  function logout() {
    token.value = null;
    currentUser.value = null;
  }

  return {
    currentUser,
    token,
    isAuthenticated,
    login,
    signup,
    logout
  };
});