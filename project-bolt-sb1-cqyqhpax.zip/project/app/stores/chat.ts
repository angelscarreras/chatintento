import { defineStore } from 'pinia';
import { ref } from 'vue';
import { api } from '../services/api';
import { websocketService } from '../services/websocket';
import type { Chat, Message } from '../types';

export const useChatStore = defineStore('chat', () => {
  const chats = ref<Chat[]>([]);
  const messages = ref<Record<string, Message[]>>({});

  async function fetchChats() {
    try {
      const response = await api.get('/chats');
      chats.value = response.data;
    } catch (error) {
      console.error('Failed to fetch chats:', error);
    }
  }

  async function fetchMessages(chatId: string) {
    try {
      const response = await api.get(`/chats/${chatId}/messages`);
      messages.value[chatId] = response.data;
    } catch (error) {
      console.error('Failed to fetch messages:', error);
    }
  }

  async function sendMessage(message: {
    chatId: string;
    content: string;
    timestamp: Date;
  }) {
    try {
      const response = await api.post(`/chats/${message.chatId}/messages`, message);
      addMessage(message.chatId, response.data);
      websocketService.sendMessage(response.data);
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  }

  function addMessage(chatId: string, message: Message) {
    if (!messages.value[chatId]) {
      messages.value[chatId] = [];
    }
    messages.value[chatId].push(message);
  }

  function updateMessageStatus(messageId: string, status: string) {
    for (const chatId in messages.value) {
      const message = messages.value[chatId].find(m => m.id === messageId);
      if (message) {
        message.status = status;
        break;
      }
    }
  }

  function joinChat(chatId: string) {
    websocketService.joinChat(chatId);
  }

  function leaveChat(chatId: string) {
    websocketService.leaveChat(chatId);
  }

  return {
    chats,
    messages,
    fetchChats,
    fetchMessages,
    sendMessage,
    addMessage,
    updateMessageStatus,
    joinChat,
    leaveChat
  };
});