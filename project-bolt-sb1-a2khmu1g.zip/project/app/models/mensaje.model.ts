export interface Mensaje {
    id: string;
    texto: string;
    usuario: string;
    fecha: number;
}