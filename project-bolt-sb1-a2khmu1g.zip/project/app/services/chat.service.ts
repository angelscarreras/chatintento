import { firebase } from '@nativescript/firebase-core';
import '@nativescript/firebase-database';
import { Observable } from '@nativescript/core';
import { Mensaje } from '../models/mensaje.model';

export class ChatService extends Observable {
    private mensajesRef: any;

    constructor() {
        super();
        this.inicializarFirebase();
    }

    private async inicializarFirebase() {
        await firebase().initializeApp();
        this.mensajesRef = firebase().database().ref('mensajes');
    }

    enviarMensaje(texto: string, usuario: string): Promise<void> {
        const mensaje: Mensaje = {
            id: Date.now().toString(),
            texto,
            usuario,
            fecha: Date.now()
        };

        return this.mensajesRef.push(mensaje);
    }

    observarMensajes(callback: (mensajes: Mensaje[]) => void) {
        this.mensajesRef.on('value', (snapshot: any) => {
            const mensajes: Mensaje[] = [];
            snapshot.forEach((child: any) => {
                mensajes.push(child.val());
            });
            callback(mensajes.sort((a, b) => a.fecha - b.fecha));
        });
    }
}