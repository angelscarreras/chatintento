import { Observable } from '@nativescript/core';
import { ChatService } from './services/chat.service';
import { Mensaje } from './models/mensaje.model';

export class ChatViewModel extends Observable {
    private chatService: ChatService;
    private _mensajes: Mensaje[] = [];
    private _nuevoMensaje: string = '';
    private _usuario: string = 'Usuario' + Math.floor(Math.random() * 1000);

    constructor() {
        super();
        this.chatService = new ChatService();
        this.inicializarChat();
    }

    private inicializarChat() {
        this.chatService.observarMensajes((mensajes) => {
            this._mensajes = mensajes;
            this.notifyPropertyChange('mensajes', mensajes);
        });
    }

    get mensajes(): Mensaje[] {
        return this._mensajes;
    }

    get nuevoMensaje(): string {
        return this._nuevoMensaje;
    }

    set nuevoMensaje(value: string) {
        if (this._nuevoMensaje !== value) {
            this._nuevoMensaje = value;
            this.notifyPropertyChange('nuevoMensaje', value);
        }
    }

    async enviarMensaje() {
        if (this._nuevoMensaje.trim()) {
            await this.chatService.enviarMensaje(this._nuevoMensaje, this._usuario);
            this.nuevoMensaje = '';
        }
    }
}